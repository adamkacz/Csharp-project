﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Projekt;

namespace JednostkoweTests
{
    [TestClass]
    public class RecenzjaTest
    {
        [TestMethod]
        public void KonstruktorOpisTest()
        {
            string opis = "";
            KontoUzytkownika k = new KontoUzytkownika();

            Recenzja r = new Recenzja(opis, k);
            Assert.AreEqual(opis, r.Opis);
        }

        [TestMethod]
        public void CompareToRTest()
        {
            Recenzja r1 = new Recenzja();
            Recenzja r2 = new Recenzja();
            Assert.AreEqual(0, r1.CompareTo(r2));
        }

        [TestMethod]
        public void EqualsRTest()
        {
            Recenzja r1 = new Recenzja();
            Recenzja r2 = new Recenzja();
            Assert.IsTrue(r1.Equals(r2));
        }

        //[TestMethod]
        //public void CloneTest()
        //{
        //    KontoUzytkownika k = new KontoUzytkownika();
        //    Recenzja r1 = new Recenzja();
        //    Recenzja r2 =(Recenzja) r1.Clone();
        //    Assert.IsTrue(Recenzja.ReferenceEquals(r1, r2));
        //}

    }
}
