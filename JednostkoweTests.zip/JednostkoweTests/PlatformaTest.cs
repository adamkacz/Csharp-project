﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Projekt;

namespace JednostkoweTests
{
    [TestClass]
    public class PlatformaTest
    {
        [TestMethod]
        public void KonstruktorNazwaTest()
        {
            string nazwa= "";

            Platforma p = new Platforma(nazwa);
            Assert.AreEqual(nazwa, p.Nazwa);
        }

        [TestMethod]
        public void DodawanieFilmowTest()
        {
            Platforma p = new Platforma();
            Film f = new Film();
            p.DodawanieFilmow(f);
            Assert.IsNotNull(f);
        }

        [TestMethod]
        public void UsunUzytkownikaTest()
        {
            Platforma p = new Platforma();
            KontoUzytkownika kU = new KontoUzytkownika();
            p.UsunUzytkownika(kU);
            Assert.IsNotNull(kU);
        }

        [TestMethod]
        public void UsunFilmTest()
        {
            Platforma p = new Platforma();
            Film f = new Film();
            p.UsunFilm(f);
            Assert.IsNotNull(f);
            
        }

        [TestMethod]
        public void ZapiszJSONTest()
        {
            Platforma p = new Platforma();
            p.ZapiszJSON("x");
            Assert.IsNotNull(p);
        }


    }
}
