﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Projekt;

namespace JednostkoweTests
{
    [TestClass]
    public class KontoAdministratoraTest
    {
        [TestMethod]
        public void KonstruktorKATest()
        {
            string login = "loggggg";
            string haslo = "hasloooo";
            string imie = "im";
            string nazwisko = "nazw";
            string email = "mailek";
            KontoAdministratora kU = new KontoAdministratora(login, haslo, imie, nazwisko, email);
            Assert.AreEqual(login, kU.Login);
            Assert.AreEqual(haslo, kU.Haslo);
            Assert.AreEqual(imie, kU.Imie);
            Assert.AreEqual(nazwisko, kU.Nazwisko);
            Assert.AreEqual(email, kU.Email);
        }
    }
}
