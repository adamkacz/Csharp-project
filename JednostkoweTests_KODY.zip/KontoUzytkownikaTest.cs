﻿using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Projekt;

namespace JednostkoweTests
{
    [TestClass]
    public class KontoUzytkownikaTest
    {
        [TestMethod]
        public void KonstruktorKUTest()
        {
            string login = "loggggg";
            string haslo = "hasloooo";
            string imie = "im";
            string nazwisko = "nazw";
            string email = "mailek";
            string dataUr = "12.06.1982";
            KontoUzytkownika kU = new KontoUzytkownika(login,haslo,imie,nazwisko,dataUr,email);
            Assert.AreEqual(login, kU.Login);
            Assert.AreEqual(haslo,kU.Haslo);
            Assert.AreEqual(imie,kU.Imie);
            Assert.AreEqual(nazwisko,kU.Nazwisko);
            Assert.AreEqual(email,kU.Email);
            Assert.AreEqual(dataUr, kU.DataUrodzenia.ToShortDateString());
        }

        [TestMethod]
        public void DodajUslugeTest()
        {
            NaPozniej usluga = new NaPozniej();
            KontoUzytkownika kU = new KontoUzytkownika();
            //List<Usluga> listaU = new List<Usluga>();
            kU.DodajUsluge(usluga);
            Assert.IsNotNull(usluga);
        }

        [TestMethod]
        public void RezygnujTest()
        {
            NaPozniej usluga = new NaPozniej();
            KontoUzytkownika kU = new KontoUzytkownika();
            List<Usluga> listaU = new List<Usluga>();
            kU.Rezygnuj(usluga);
            Assert.IsNotNull(usluga);
            Assert.IsNotNull(listaU);
            Assert.IsFalse(listaU.Contains(usluga));
        }

        [TestMethod]
        public void ObliczOplateTest()
        {
            NaPozniej usluga = new NaPozniej();
            KontoUzytkownika kU = new KontoUzytkownika();
            kU.DodajUsluge(usluga);
            double koszt = KontoUzytkownika.Abonament + usluga.Koszt;
            Assert.AreEqual(koszt,kU.ObliczOplate());
        }

        [TestMethod]
        [ExpectedException(typeof(BrakUprawnienException))]
        public void BladDodajDoObejrzeniaTest()
        {
            Film f = new Film();
            KontoUzytkownika kU = new KontoUzytkownika();
            kU.DodajDoObejrzenia(f);
            Assert.Fail("Nie ma wyjątku.");
        }

        [TestMethod]
        [ExpectedException(typeof(BrakUprawnienException))]
        public void UsunZListyDoObejrzeniaTest()
        {
            Film f = new Film();
            KontoUzytkownika kU = new KontoUzytkownika();
            kU.UsunZListyDoObejrzenia(f);
            Assert.Fail("Nie ma wyjątku.");
        }

        [TestMethod]
        public void WyborTest()
        {
            NaPozniej u = new NaPozniej();
            KontoUzytkownika kU = new KontoUzytkownika();
            kU.Wybor(u);
            Assert.IsNotNull(u);
        }

        [TestMethod]
        [ExpectedException(typeof(BrakUprawnienException))]
        public void DodajRecenzjeTest()
        {
            Film f = new Film();
            Recenzja rec = new Recenzja();
            KontoUzytkownika kU = new KontoUzytkownika();
            kU.DodajRecenzje(rec, f);
            Assert.Fail("Nie ma wyjątku.");
        }

        [TestMethod]
        [ExpectedException(typeof(BrakUprawnienException))]
        public void EdytujRecenzjeTest()
        {
            Film f = new Film();
            Recenzja rec = new Recenzja();
            KontoUzytkownika kU = new KontoUzytkownika();
            kU.EdytujRecenzje(rec, f);
            Assert.Fail("Nie ma wyjątku.");
        }

        [TestMethod]
        [ExpectedException(typeof(BrakUprawnienException))]
        public void UsunRecenzjeTest()
        {
            Film f = new Film();
            Recenzja rec = new Recenzja();
            KontoUzytkownika kU = new KontoUzytkownika();
            kU.UsunRecenzje(rec, f);
            Assert.Fail("Nie ma wyjątku.");
        }
    }
}
