﻿using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Projekt;

namespace JednostkoweTests
{
    [TestClass]
    public class NaPozniejTest
    {
        [TestMethod]
        public void DodajDoObejrzeniaTest()
        {
            List<Film> lista = new List<Film>();
            Film f = new Film();
            NaPozniej.DodajDoObejrzenia(f,lista);
            Assert.IsTrue(lista.Contains(f));
            Assert.IsNotNull(f);

        }

        [TestMethod]
        public void UsunTest()
        {
            List<Film> lista = new List<Film>();
            Film f = new Film();
            NaPozniej.Usun(f, lista);
            Assert.IsFalse(lista.Contains(f));
            Assert.IsNotNull(f);

        }
    }
}
