﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Projekt;

namespace JednostkoweTests
{
    [TestClass]
    public class FilmTest
    {
        [TestMethod]
        public void KonstruktorFTest()
        {
            string tytul = "";
            int ograniczenie = 12;
            Gatunek gatunek=Gatunek.komedia;
            string path = "";

            Film f = new Film(tytul, Gatunek.komedia, ograniczenie,path);
            Assert.AreEqual(tytul, f.Tytul);
            Assert.AreEqual(ograniczenie, f.OgraniczenieWiekowe);
            Assert.AreEqual(gatunek,f.Gatunek);
            Assert.AreEqual(path, f.Path);
        }

        [TestMethod]
        public void CompareToFTest()
        {
            Film f1 = new Film();
            Film f2 = new Film();
            f1.Tytul = "Abe";
            f2.Tytul = "Graham";
            Assert.AreEqual(1, f2.CompareTo(f1));
        }
    }
}
