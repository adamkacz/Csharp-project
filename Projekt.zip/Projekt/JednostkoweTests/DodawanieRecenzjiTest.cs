﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Projekt;

namespace JednostkoweTests
{
    [TestClass]
    public class DodawanieRecenzjiTest
    {
        [TestMethod]
        public void DodajRecenzjeTest()
        {
            Recenzja r = new Recenzja();
            Film f =new Film();
            DodawanieRecenzji.DodajRecenzje(r, f);
            Assert.IsTrue(f.ListaRecenzji.Contains(r));
            Assert.IsNotNull(r);

        }

        [TestMethod]
        public void UsunRecenzjeTest()
        {
            Recenzja r = new Recenzja();
            Film f = new Film();
            DodawanieRecenzji.UsunRecenzje(r, f);
            Assert.IsFalse(f.ListaRecenzji.Contains(r));
            Assert.IsNotNull(r);

        }

        [TestMethod]
        public void EdytujRecenzjeTest()
        {
            Recenzja r = new Recenzja();
            Film f = new Film();
            DodawanieRecenzji.EdytujRecenzje(r, f);
            Recenzja klon = r;
            Assert.AreEqual(r,klon);
            Assert.IsNotNull(r);

        }

    }
}
