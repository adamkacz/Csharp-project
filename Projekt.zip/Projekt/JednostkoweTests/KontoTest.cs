﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Projekt;

namespace JednostkoweTests
{
    [TestClass]
    public class KontoTest
    {
        [TestMethod]
        public void KonstruktorKTest()
        {
            string login = "loggggg";
            string haslo = "hasloooo";
            string imie = "im";
            string nazwisko = "nazw";
            string email = "mailek";
            Konto kU = new Konto(login, haslo, imie, nazwisko, email);
            Assert.AreEqual(login, kU.Login);
            Assert.AreEqual(haslo, kU.Haslo);
            Assert.AreEqual(imie, kU.Imie);
            Assert.AreEqual(nazwisko, kU.Nazwisko);
            Assert.AreEqual(email, kU.Email);
        }

        //[TestMethod]
        //[ExpectedException(typeof(HasloException),"Błąd. Zbyt krótkie hasło.")]
        //public void setHasloTest()
        //{
        //    Konto k = new Konto();
        //    k.setHaslo("xx");
        //    Assert.Fail("Nie ma wyjątku");
        //}

        //[TestMethod]
        //[ExpectedException(typeof(LoginException), "Błąd. Login nie może być krótszy niż 3 znaki ani dłuższy niż 19.")]
        //public void setLoginTest()
        //{
        //    Konto k1 = new Konto();
        //    k1.setLogin("x");
        //    Assert.Fail("Nie ma wyjątku.");
        //}

        [TestMethod]
        public void EqualsKTest()
        {
            Konto k1 = new Konto();
            Konto k2 = new Konto();
            k1.Login = "123456";
            k2.Login = "654321";
            Assert.IsFalse(k1.Equals(k2));
        }
    }
}
