﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Projekt;
using System.IO;


namespace GUI
{
    /// <summary>
    /// Interaction logic for ListaFilmow.xaml
    /// </summary>
    public partial class ListaFilmow : Window
    {
        Platforma platforma;
        Projekt.KontoUzytkownika konto;
        ObservableCollection<Film> lista;

        public ListaFilmow()
        {
            InitializeComponent();
        }

        public ListaFilmow(Platforma p, Projekt.KontoUzytkownika k) : this()
        {
            platforma = p;
            konto = k;
            lista = new ObservableCollection<Film>();
            lista = new ObservableCollection<Film>(platforma.ListaFilmow);
            LBListaFilmow.ItemsSource = lista;
        }

        

        private void LBListaFilmow_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            int zaznaczony = LBListaFilmow.SelectedIndex;
            if(zaznaczony == -1)
            {
                MessageBox.Show("Wybierz film!");
                return;
            }
            if(lista.ElementAt(zaznaczony).OgraniczenieWiekowe > konto.Wiek())
            {
                MessageBox.Show("Twój wiek nie odpowiada ograniczeniu wiekowemu nałożonemu na film!\nWybierz inny film.", "UWAGA !!!");
                return;
            }

            OgladanieFilmu okno = new OgladanieFilmu(platforma.ListaFilmow.ElementAt(zaznaczony), konto, platforma);
            okno.ShowDialog();
        }


        private void BTDodajDoUlubionych_Click(object sender, RoutedEventArgs e)
        {
            int zaznaczony = LBListaFilmow.SelectedIndex;
            if (zaznaczony == -1)
            {
                MessageBox.Show("Wybierz film!", "UWAGA !!!");
                return;
            }
            try
            {
                konto.DodajDoObejrzenia(platforma.ListaFilmow.ElementAt(zaznaczony));
                platforma.ZapiszJSON("platforma.json");
                MessageBox.Show("Dodano film do obejrzenia na później.", "UWAGA !!!");
            }
            catch(BrakUprawnienException)
            {
                MessageBox.Show("Nie masz uprawnień do wykonania tej akcji.\nJeśli chcesz, dodaj usługę 'Dodaj do obejrzenia' z panelu swojego konta.", "UWAGA !!!");
                return;
            }
        }
    }
}
