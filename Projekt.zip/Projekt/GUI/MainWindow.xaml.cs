﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Projekt;

namespace GUI
{
    /// <summary>
    /// Logika interakcji dla klasy MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Platforma platforma;
        

        public MainWindow()
        {
            InitializeComponent();
            platforma = Platforma.OdczytajJSON("platforma.json");
            Projekt.KontoUzytkownika.Abonament = 10.0;
            //platforma = new Platforma("Halina");
            //platforma.ListaAdmin.Add(new Projekt.KontoAdministratora("admin", "adminadmin", "adam", "kaczmarczyk", "ad@in.pl"));

        }

        

        private void BTZaloguj_Click(object sender, RoutedEventArgs e)
        {
            string login;
            string haslo;

            Projekt.KontoUzytkownika uzytkownik = new Projekt.KontoUzytkownika();
            Projekt.KontoAdministratora admin = new Projekt.KontoAdministratora();
            
            if (TBLogin.Text == "" || TBPassword.Password == "")
            {
                MessageBox.Show("Uzupełnij login lub hasło", "UWAGA !!!");
                return;
            }

            login = TBLogin.Text;
            haslo = TBPassword.Password;

            
            if((uzytkownik = platforma.ListaKont.Find(u => u.Login == login))==null)
            {
                if ((admin = platforma.ListaAdmin.Find(a => a.Login == login)) == null)
                {
                    MessageBox.Show("Błędny login!", "UWAGA !!!");
                    TBLogin.Text =TBPassword.Password="";
                    return;
                }
            }

            if (uzytkownik != null)
            {
                if (uzytkownik.Haslo == haslo)
                {
                    KontoUzytkownika okno = new KontoUzytkownika(uzytkownik, platforma);
                    TBLogin.Text = "";
                    TBPassword.Password = "";
                    this.Close();
                    okno.ShowDialog();
                    
                }
                else
                {
                    MessageBox.Show("Błędne hasło", "UWAGA !!!");
                    TBPassword.Password = "";
                    return;
                }
            }
            else
            {
                if (admin.Haslo == haslo)
                {
                    KontoAdministratora okno = new KontoAdministratora(admin,platforma);
                    TBLogin.Text = "";
                    TBPassword.Password = "";
                    this.Close();
                    okno.ShowDialog();
                    
                }
                else
                {
                    MessageBox.Show("Błędne hasło", "UWAGA !!!");
                    TBPassword.Password = "";
                    return;
                }
            }

        }

        private void BTZarejestruj__Click(object sender, RoutedEventArgs e)
        {
            Projekt.KontoUzytkownika Ku = new Projekt.KontoUzytkownika();
            RejestracjaWindow rej = new RejestracjaWindow(Ku, platforma.ListaKont, platforma.ListaAdmin);
            rej.ShowDialog();
            platforma.ListaKont.Add(Ku);
            platforma.ListaKont.Sort();

            Projekt.KontoAdministratora ka = new Projekt.KontoAdministratora("admin", "adminadmin", "adam", "kaczmarczyk", "hsgg@pl.pl");
            platforma.ListaAdmin.Add(ka);
            try
            {
                platforma.ZapiszJSON("platforma.json");
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }        
    }
}
