﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Projekt;

namespace GUI
{
    /// <summary>
    /// Interaction logic for KontoAdministratora.xaml
    /// </summary>
    public partial class KontoAdministratora : Window
    {
        Projekt.KontoAdministratora konto;
        Platforma platforma;
        ObservableCollection<Film> lista;
        ObservableCollection<Projekt.KontoUzytkownika> lista2;

        public KontoAdministratora()
        {
            InitializeComponent();
        }

        public KontoAdministratora(Projekt.KontoAdministratora k,Platforma p) : this()
        {
            platforma = p;
            konto = k;

            lista = new ObservableCollection<Film>();
            lista = new ObservableCollection<Film>(platforma.ListaFilmow);
            LBListaFilmow.ItemsSource = lista;

            lista2 = new ObservableCollection<Projekt.KontoUzytkownika>();
            lista2 = new ObservableCollection<Projekt.KontoUzytkownika>(platforma.ListaKont);
            LBListaKont.ItemsSource = lista2;
        }

        private void BTUsunFilm_Click(object sender, RoutedEventArgs e)
        {
            int zaznaczony = LBListaFilmow.SelectedIndex;
            if (zaznaczony == -1)
            {
                MessageBox.Show("Wybierz usługę!", "UWAGA !!!");
                return;
            }

            platforma.UsunFilm(lista.ElementAt(zaznaczony));
            platforma.ZapiszJSON("platforma.json");
            lista.RemoveAt(zaznaczony);
            LBListaFilmow.Items.Refresh();
        }

        private void BTDodajFilm_Click(object sender, RoutedEventArgs e)
        {
            Film f = new Film();
            DodajFilm okno = new DodajFilm(f,konto,platforma);
            okno.ShowDialog();
            platforma.DodawanieFilmow(f);
            platforma.ListaFilmow.Sort();
            lista.Add(f);
            platforma.ZapiszJSON("platforma.json");

        }

        private void BTUsunKKFilm_Click(object sender, RoutedEventArgs e)
        {
            int zaznaczony = LBListaKont.SelectedIndex;
            if (zaznaczony == -1)
            {
                MessageBox.Show("Wybierz usługę!", "UWAGA !!!");
                return;
            }

            platforma.UsunUzytkownika(lista2.ElementAt(zaznaczony));
            platforma.ZapiszJSON("platforma.json");
            lista2.RemoveAt(zaznaczony);
            LBListaKont.Items.Refresh();

        }
    }
}
