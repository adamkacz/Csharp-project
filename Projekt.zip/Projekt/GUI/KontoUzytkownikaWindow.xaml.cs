﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Projekt;

namespace GUI
{
    /// <summary>
    /// Logika interakcji dla klasy KontoUzytkownika.xaml
    /// </summary>
    public partial class KontoUzytkownika : Window
    {
        Projekt.KontoUzytkownika konto;
        Platforma platforma;

        public KontoUzytkownika()
        {

        }

        public KontoUzytkownika(Projekt.KontoUzytkownika k, Platforma p) : this()
        {
            InitializeComponent();
            konto = k;
            platforma = p;
        }

        private void BTZmienHasło_Click(object sender, RoutedEventArgs e)
        {
            ZmianaHasla okno = new ZmianaHasla(konto);
            okno.ShowDialog();
            platforma.ZapiszJSON("platforma.json");
        }

        private void BTPrzegladajUsługi_Click(object sender, RoutedEventArgs e)
        {
            Uslugi okno = new Uslugi(konto,platforma);
            okno.ShowDialog();

        }

        

        private void BTDodajUsługę_Copy_Click(object sender, RoutedEventArgs e)
        {
            Ulubione okno = new Ulubione(konto,platforma);
            okno.ShowDialog();

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            ListaFilmow okno = new ListaFilmow(platforma, konto);
            okno.ShowDialog();
        }
    }
}
