﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Projekt;

namespace GUI
{
    /// <summary>
    /// Logika interakcji dla klasy RejestracjaWindow.xaml
    /// </summary>
    public partial class RejestracjaWindow : Window
    {
        Projekt.KontoUzytkownika konto;
        List<Projekt.KontoUzytkownika> listaK;
        List<Projekt.KontoAdministratora> listaA;

        public RejestracjaWindow() 
        {
            InitializeComponent();
        }

        public RejestracjaWindow(Projekt.KontoUzytkownika k, List<Projekt.KontoUzytkownika> listaK,
                                                        List<Projekt.KontoAdministratora> listaA) : this()
        {
            this.konto = k;
            this.listaK = listaK;
            this.listaA = listaA;
        }

        private void BTZatwierdz_Click(object sender, RoutedEventArgs e)
        {
            string imie = TBImię.Text;
            string nazwisko = TBNazwisko.Text;
            string haslo = PBHaslo.Password;
            string email = TBEmail.Text;
            string login = TBLogin.Text;
            DateTime dataUrodzenia = DPDataUr.DisplayDate;

            if(imie == "" || nazwisko == "" || haslo == "" || email == "" || login == "")
            {
                MessageBox.Show("Uzupełnij wszystkie pola!", "UWAGA !!!");
                return;
            }

            foreach(Projekt.KontoUzytkownika k in listaK)
            {
                if(k.Login == login)
                {
                    MessageBox.Show($"Istnieje już konto o podanym loginie.{Environment.NewLine}Wybierz inny login.", "UWAGA !!!");
                    return;
                }
            }

            foreach (Projekt.KontoAdministratora k in listaA)
            {
                if (k.Login == login)
                {
                    MessageBox.Show($"Istnieje już konto o podanym loginie.{Environment.NewLine}Wybierz inny login.", "UWAGA !!!");
                    return;
                }
            }

            if (PBHaslo.Password != PBPowtorzHaslo.Password)
            {
                MessageBox.Show("Hasło i powtórzone hasło różnią się od siebie.", "UWAGA !!!");
                return;
            }

            if (dataUrodzenia > DateTime.Now)
            {
                MessageBox.Show("Niepoprawna data urodzenia.", "UWAGA !!!");
                return;
            }

            if(email.Contains("@"))
            {
                string[] s = email.Split('@');
                if(s.Length > 2)
                {
                    MessageBox.Show("Niepoprawny email.", "UWAGA !!!");
                    return;
                }
                if(!s[1].Contains('.') || s[1][0] == '.' || s[1][s[1].Length - 1] == '.')
                {
                    MessageBox.Show("Niepoprawny email.", "UWAGA !!!");
                    return;
                }
            }
            else
            {
                MessageBox.Show("Niepoprawny email.", "UWAGA !!!");
                return;
            }

            if(haslo.Length <= 6)
            {
                MessageBox.Show("Hasło jest zbyt krótkie. Powinno mieć więcej niż 6 znaków!", "UWAGA !!!");
                return;
            }

            if ((login.Length < 3) && (login.Length > 19))
            {
                MessageBox.Show("Login powinien zwierać od 4 do 19 znaków!", "UWAGA !!!");
                return;
            }
            
            this.konto.Email = email;
            this.konto.Imie = imie;
            this.konto.Nazwisko = nazwisko;
            this.konto.DataUrodzenia = dataUrodzenia;
            this.konto.Haslo = haslo;
            this.konto.Login = login;

            
            this.Close();
        }
    }
}
