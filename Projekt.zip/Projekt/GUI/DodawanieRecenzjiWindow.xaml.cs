﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Projekt;

namespace GUI
{
    /// <summary>
    /// Interaction logic for DodawanieRecenzji.xaml
    /// </summary>
    public partial class DodawanieRecenzji : Window
    {
        bool edit;
        Recenzja recenzja;

        public DodawanieRecenzji()
        {
            InitializeComponent();
        }

        public DodawanieRecenzji(Recenzja r, bool edit) : this()
        {
            recenzja = r;
            this.edit = edit;
            if (edit)
            {
                TBRecenzja.Text = r.Opis;
            }
        }

        private void TBRecenzja_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void BTDodajRecenzje_Click(object sender, RoutedEventArgs e)
        {
            if(TBRecenzja.Text != "" && TBRecenzja.Text.Length <= 160)
            {
                recenzja.Opis = TBRecenzja.Text;
                Close();
            }
            else if(TBRecenzja.Text.Length > 160)
            {
                MessageBox.Show("Zbyt długa recenzja! Max 160 znaków.", "UWAGA !!!");
                return;
            }
            else
            {
                MessageBox.Show("Uzupełnij recenzję!", "UWAGA !!!");
                return;
            }
        }
    }
}
