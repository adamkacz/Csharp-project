﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GUI
{
    /// <summary>
    /// Interaction logic for ZmianaHasla.xaml
    /// </summary>
    public partial class ZmianaHasla : Window
    {
        Projekt.KontoUzytkownika uzytkownik;

        public ZmianaHasla()
        {
            InitializeComponent();
        }

        public ZmianaHasla(Projekt.KontoUzytkownika u) :this()
        {
            uzytkownik = u;
        }

        private void BTZatwierdz_Click(object sender, RoutedEventArgs e)
        {
            if(PBStarehaslo.Password == uzytkownik.Haslo)
            {
                if(PBNowehaslo.Password == "" || PBPowtorzhaslo.Password == "")
                {
                    PBNowehaslo.Password = PBPowtorzhaslo.Password = PBStarehaslo.Password = "";
                    MessageBox.Show("Uzupełnij wszystkie pola!","UWAGA !!!");
                    return;
                }
                else if(PBNowehaslo.Password == PBPowtorzhaslo.Password && PBNowehaslo.Password != uzytkownik.Haslo)
                {
                    if (PBNowehaslo.Password.Length < 6)
                    {
                        PBNowehaslo.Password = PBPowtorzhaslo.Password = PBStarehaslo.Password = "";
                        MessageBox.Show("Hasło jest zbyt krótkie. Powinno mieć więcej niż 6 znaków!", "UWAGA !!!");
                        return;
                    }
                    uzytkownik.Haslo = PBNowehaslo.Password;
                }
                else if(PBNowehaslo.Password != PBPowtorzhaslo.Password)
                {
                    PBNowehaslo.Password = PBPowtorzhaslo.Password = PBStarehaslo.Password = "";
                    MessageBox.Show("Wpisane hasła nie są zgodne!", "UWAGA !!!");
                    return;
                }
                else
                {
                    PBNowehaslo.Password = PBPowtorzhaslo.Password = PBStarehaslo.Password = "";
                    MessageBox.Show("Nowe hasło nie może być takie samo jak stare hasło!!!", "UWAGA !!!");
                    return;
                }
            }
            else
            {
                PBNowehaslo.Password = PBPowtorzhaslo.Password = PBStarehaslo.Password = "";
                MessageBox.Show("Hasło użytkownika jest niepoprawne!", "UWAGA !!!");
                return;
            }
            
            Close();
        }
    }
}
