﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Projekt;

namespace GUI
{
    /// <summary>
    /// Interaction logic for Ulubione.xaml
    /// </summary>
    public partial class Ulubione : Window
    {
        Projekt.KontoUzytkownika uzytkownik;
        Platforma platforma;
        ObservableCollection<string> lista;

        public Ulubione()
        {
            InitializeComponent();
        }

        public Ulubione(Projekt.KontoUzytkownika u,Platforma p) : this()
        {
            uzytkownik = u;
            platforma = p;

            lista = new ObservableCollection<string>();
            lista = new ObservableCollection<string>(uzytkownik.ListaNaPozniej);
            LBListaUlubionychFilmow.ItemsSource = lista;

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            int zaznaczony = LBListaUlubionychFilmow.SelectedIndex;
            
            if (zaznaczony == -1)
            {
                MessageBox.Show("Wybierz film!", "UWAGA !!!");
                return;
            }
            Film film = platforma.ListaFilmow.Find(f => f.ToString() == lista.ElementAt(zaznaczony));
            if (film.OgraniczenieWiekowe > uzytkownik.Wiek())
            {
                MessageBox.Show("Twój wiek nie odpowiada ograniczeniu wiekowemu nałożonemu na film!\nWybierz inny film.", "UWAGA !!!");
                return;
            }

            
            OgladanieFilmu okno = new OgladanieFilmu(film, uzytkownik, platforma);
            okno.ShowDialog();
        }

        private void LBListaUlubionychFilmow_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void ButtonUsuńU_Click(object sender, RoutedEventArgs e)
        {
            int zaznaczony = LBListaUlubionychFilmow.SelectedIndex;
            if (zaznaczony == -1)
            {
                MessageBox.Show("Wybierz film!", "UWAGA !!!");
                return;
            }

            Film f = platforma.ListaFilmow.Find(fi => fi.ToString() == lista.ElementAt(zaznaczony));
            uzytkownik.UsunZListyDoObejrzenia(f);
            platforma.ZapiszJSON("platforma.json");
            lista.RemoveAt(zaznaczony);
            LBListaUlubionychFilmow.Items.Refresh();

        }
    }
}
