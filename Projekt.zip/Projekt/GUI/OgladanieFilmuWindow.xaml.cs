﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;
using Projekt;
using System.IO;
using System.Runtime;

namespace GUI
{
    /// <summary>
    /// Interaction logic for OgladanieFilmu.xaml
    /// </summary>
    public partial class OgladanieFilmu : Window
    {
        Film film;
        Projekt.KontoUzytkownika uzytkownik;
        Platforma platforma;
        DispatcherTimer timer;
        ObservableCollection<Recenzja> lista;
        

        public OgladanieFilmu()
        {
            InitializeComponent();
        }

        public OgladanieFilmu(Film f, Projekt.KontoUzytkownika u, Platforma p) : this()
        {
            string sciezka;

            film = f;
            uzytkownik = u;
            platforma = p;

            TBTytulFilmu.Text = film.Tytul;
            sciezka = $"{Directory.GetCurrentDirectory()}\\{film.Path}";
            sciezka = sciezka.Replace('\\', '/');
            try
            {
                MEFilm.Source = new Uri(sciezka);
            }
            catch
            {
                MessageBox.Show("Plik uszkodzony!");
            }

            MEFilm.LoadedBehavior = MediaState.Manual;
            MEFilm.Volume = SliderVolume.Value;
            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromMilliseconds(500);
            timer.Tick += new EventHandler(timer_Tick);
            lista = new ObservableCollection<Recenzja>();
            lista = new ObservableCollection<Recenzja>(film.ListaRecenzji);
            LBListaRecenzji.ItemsSource = lista;
            ArrayList indeksy = new ArrayList();
            foreach(Recenzja r in lista)
            {
                if (r.Edytowana)
                    indeksy.Add(lista.IndexOf(r));
            }

            foreach (int indeks in indeksy)
                lista.RemoveAt(indeks);

        }

        void timer_Tick(object sender, EventArgs e)
        {
            SliderTrwanie.Value = MEFilm.Position.TotalSeconds;
        }


        private void Start_Click(object sender, RoutedEventArgs e)
        {
            MEFilm.Play();
        }

        private void TBTytulFilmu_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void LBListaRecenzji_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void BTDodajRecenzje_Click(object sender, RoutedEventArgs e)
        {
            Projekt.DodawanieRecenzji dod = new Projekt.DodawanieRecenzji();
            if(!uzytkownik.ListaUslug.Contains(dod.ToString()))
            {
                MessageBox.Show("Nie masz uprawnień do wykonania tej akcji.\nJeśli chcesz, dodaj usługę 'Dodawanie recencji' z panelu swojego konta.", "UWAGA !!!");
                return;
            }
            Recenzja r = new Recenzja();
            DodawanieRecenzji okno = new DodawanieRecenzji(r, false);
            okno.ShowDialog();
            r.Uzytkownik = uzytkownik;
            film.ListaRecenzji.Add(r);
            film.ListaRecenzji.Sort();
            lista.Add(r);
            platforma.ZapiszJSON("platforma.json");
        }

        private void Pause_Click(object sender, RoutedEventArgs e)
        {
            MEFilm.Pause();
        }

        private void Stop_Click(object sender, RoutedEventArgs e)
        {
            MEFilm.Stop();
        }

        private void SliderVolume_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            MEFilm.Volume = SliderVolume.Value;
        }

        private void SliderTrwanie_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            MEFilm.Position = TimeSpan.FromSeconds(SliderTrwanie.Value);
        }

        private void MEFilm_MediaOpened(object sender, RoutedEventArgs e)
        {
            TimeSpan ts = MEFilm.NaturalDuration.TimeSpan;
            SliderTrwanie.Maximum = ts.TotalSeconds;
            timer.Start();
        }

        private void BTEdytujRecenzje_Click(object sender, RoutedEventArgs e)
        {
            int zaznaczony = LBListaRecenzji.SelectedIndex;
            if (zaznaczony == -1)
            {
                MessageBox.Show("Wybierz recenzję!", "UWAGA !!!");
                return;
            }

            Projekt.DodawanieRecenzji dod = new Projekt.DodawanieRecenzji();

            if (!lista.ElementAt(zaznaczony).Uzytkownik.Equals(uzytkownik) || !uzytkownik.ListaUslug.Contains(dod.ToString()))
            {
                MessageBox.Show("Nie masz uprawnień do wykonania tej akcji!\n" +
                    "Upewnij się czy wykupiłeś usługę lub czy nie zaznaczyłeś opinii innego użytkownika", "UWAGA !!!");
                return;
            }

            
            Recenzja r = lista.ElementAt(zaznaczony).Clone() as Recenzja;
            DodawanieRecenzji okno = new DodawanieRecenzji(r, true);
            okno.ShowDialog();
            if(r.Opis == lista.ElementAt(zaznaczony).Opis)
            {
                MessageBox.Show("Recenzja nie uległa zmianie, gdyż jej treść jest taka sama jak wcześniej!", "UWAGA !!!");
                return;
            }
            
            lista.ElementAt(zaznaczony).Edytowana = true;
            film.ListaRecenzji.Add(r);
            lista.Add(r);
            lista.RemoveAt(zaznaczony);
            film.ListaRecenzji.Sort();
            platforma.ZapiszJSON("platforma.json");
        }
    }
}
