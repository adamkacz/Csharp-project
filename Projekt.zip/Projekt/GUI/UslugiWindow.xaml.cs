﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Projekt;

namespace GUI
{
    /// <summary>
    /// Interaction logic for Uslugi.xaml
    /// </summary>
    public partial class Uslugi : Window
    {
        Projekt.KontoUzytkownika uzytkownik;
        Platforma platforma;
        ObservableCollection<string> lista;
        ObservableCollection<string> lista2;
        public Uslugi()
        {
            InitializeComponent();
        }

        public Uslugi(Projekt.KontoUzytkownika u, Platforma p) : this()
        {
            uzytkownik = u;
            platforma = p;
            NaPozniej naPozniej = new NaPozniej();
            Projekt.DodawanieRecenzji dodRec = new Projekt.DodawanieRecenzji();

            lista2 = new ObservableCollection<string>();
            lista2 = new ObservableCollection<string>(uzytkownik.ListaUslug);
            LBDostepneUslugi.ItemsSource = lista2;


            lista = new ObservableCollection<string>();
            if(!lista2.Contains(naPozniej.ToString()))
                lista.Add(new NaPozniej().ToString());

            if (!lista2.Contains(dodRec.ToString()))
                lista.Add(new Projekt.DodawanieRecenzji().ToString());

            LBKupUsluge.ItemsSource = lista;            
        }

        private void BTDodajUsługę_Click(object sender, RoutedEventArgs e)
        {
            int zaznaczony = LBKupUsluge.SelectedIndex;
            if (zaznaczony == -1)
            {
                MessageBox.Show("Wybierz usługę!", "UWAGA !!!");
                return;
            }

            uzytkownik.DodajUsluge(lista.ElementAt(zaznaczony));
            lista2.Add(lista.ElementAt(zaznaczony));
            lista.Remove(lista.ElementAt(zaznaczony));
            platforma.ZapiszJSON("platforma.json");
            LBDostepneUslugi.Items.Refresh();

        }

        private void BTUsunUsługę_Click(object sender, RoutedEventArgs e)
        {
            int zaznaczony = LBDostepneUslugi.SelectedIndex;
            if (zaznaczony == -1)
            {
                MessageBox.Show("Wybierz usługę!", "UWAGA !!!");
                return;
            }

            uzytkownik.Rezygnuj(lista2.ElementAt(zaznaczony));
            uzytkownik.ListaUslug.Remove(lista2.ElementAt(zaznaczony));
            lista.Add(lista2.ElementAt(zaznaczony));
            platforma.ZapiszJSON("platforma.json");
            lista2.RemoveAt(zaznaczony);
            LBDostepneUslugi.Items.Refresh();
        }

        private void LBKupUsluge_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
