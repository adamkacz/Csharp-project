﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Projekt;

namespace GUI
{
    /// <summary>
    /// Interaction logic for DodajFilm.xaml
    /// </summary>
    public partial class DodajFilm : Window
    {
        Projekt.KontoAdministratora konto;
        Film film;
        Platforma platforma;
        public DodajFilm()
        {
            InitializeComponent();
        }

        public DodajFilm(Film f, Projekt.KontoAdministratora k, Platforma p) : this()
        {
            film = f;
            konto = k ;
            platforma = p;

            string tytul = TBTytul.Text;
            if ((film.Gatunek) == Gatunek.dokumentalny)
                CBGatunek.Text = "Dokumentalny";
            else if ((film.Gatunek) == Gatunek.fantasy)
                CBGatunek.Text = "Fantasy";
            if ((film.Gatunek) == Gatunek.horror)
                CBGatunek.Text = "Horror";
            if ((film.Gatunek) == Gatunek.komedia)
                CBGatunek.Text = "Komedia";
            if ((film.Gatunek) == Gatunek.romantyczny)
                CBGatunek.Text = "Romantyczny";
            else
                CBGatunek.Text = "Thriller";
            string ograniczenie = TBOgraniczenieWiekowe.Text;
            string path = TBNazwaPliku.Text;
        }

        private void TBTytul_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void TBGatunek_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void TBOgraniczenieWiekowe_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void BTZatwierdz_Click(object sender, RoutedEventArgs e)
        {
            int liczba;

            if (TBTytul.Text == "" || CBGatunek.Text == "" || TBNazwaPliku.Text==""||TBOgraniczenieWiekowe.Text=="")
            {
                MessageBox.Show("Uzupełnij wszystkie pola!", "UWAGA !!!");
                return;
            }

            if(platforma.ListaFilmow.Find(film => film.Tytul == TBTytul.Text) != null)
            {
                MessageBox.Show("W bazie istnieje już film o podanym tytule.\n" +
                    "Jeżeli nie chcesz go zmieniać dodaj do tytułu element wyróżniający taki jak reżyser", "UWAGA!");
                return;
            }

            if(!Int32.TryParse(TBOgraniczenieWiekowe.Text, out liczba))
            {
                MessageBox.Show("Błędne dane w rubryce 'Ograniczenie wiekowe'", "UWAGA!");
                return;
            }
            
            this.film.Tytul=TBTytul.Text;
            
            switch (CBGatunek.Text)
            {
                case "Dokumentalny":
                    this.film.Gatunek = Gatunek.dokumentalny;
                    break;

                case "Fantasy":
                    this.film.Gatunek = Gatunek.fantasy;
                    break;
            
                case "Horror":
                    this.film.Gatunek = Gatunek.horror;
                    break;

                case "Komedia":
                    this.film.Gatunek = Gatunek.komedia;
                    break;
                default:
                this.film.Gatunek = Gatunek.thriller;
                    break;
            }
            
            this.film.OgraniczenieWiekowe = liczba;
            this.film.Path = TBNazwaPliku.Text;

            this.Close();

        }
    }
}
