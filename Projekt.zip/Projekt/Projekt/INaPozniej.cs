﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projekt
{
    interface INaPozniej
    {
        void DodajDoObejrzenia(Film f);
        void UsunZListyDoObejrzenia(Film f);
    }
}