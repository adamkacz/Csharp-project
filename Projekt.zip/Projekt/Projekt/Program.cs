﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projekt
{
    public class Program
    {
        static void Main(string[] args)
        {
            Platforma platforma = new Platforma("Halina");
            platforma.ListaKont.Add(new KontoUzytkownika("ihduhsd", "dsjadsghs", "wiyegaaaaa", "gadAAAAAsvk", DateTime.Now.AddYears(-1), "as@iji.pl"));
            platforma.ZapiszJSON("cons.json");
            Platforma platforma1 = Platforma.OdczytajJSON("cons.json");
            platforma1.ListaKont.ForEach(k => Console.WriteLine(k));
        }

        public static void Wypisz(Platforma p)
        {
            int i = 0;
            Console.WriteLine("działam");
            foreach (KontoUzytkownika k in p.ListaKont)
            {
                Console.WriteLine(i + $"........................{k.Login}");
                ++i;
            }
        }
    }
}
