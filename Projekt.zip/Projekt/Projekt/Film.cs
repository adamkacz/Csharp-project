﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Projekt
{
    [Serializable]
    public enum Gatunek { komedia, horror, romantyczny, dokumentalny, fantasy, thriller }
    [Serializable]
    [DataContract]
    public class Film : IComparable<Film>
    {
        string tytul;
        Gatunek gatunek;
        int ograniczenieWiekowe;
        List<Recenzja> listaRecenzji;
        string path;

        [DataMember]
        public string Tytul { get => tytul; set => tytul = value; }
        [DataMember]
        public int OgraniczenieWiekowe { get => ograniczenieWiekowe; set => ograniczenieWiekowe = value; }
        [DataMember]
        public Gatunek Gatunek { get => gatunek; set => gatunek = value; }
        [DataMember]
        public List<Recenzja> ListaRecenzji { get => listaRecenzji; set => listaRecenzji = value; }
        [DataMember]
        public string Path { get => path; set => path = value; }

        public Film()
        {
            Tytul = "";
            ograniczenieWiekowe = 0;
            ListaRecenzji = new List<Recenzja>();
            Path = "";
        }

        public Film(string tytul, Gatunek gatunek, int ograniczenieWiekowe, string path)
        {
            Tytul = tytul;
            this.Gatunek = gatunek;
            OgraniczenieWiekowe = ograniczenieWiekowe;
            ListaRecenzji = new List<Recenzja>();
            Path = path;
        }

        public override string ToString()
        {
            return $"'{tytul}', {gatunek}, Minimalny wiek: {ograniczenieWiekowe}";
        }


        public int CompareTo(Film f)
        {
            return Tytul.CompareTo(f.Tytul);
        }
    }

}