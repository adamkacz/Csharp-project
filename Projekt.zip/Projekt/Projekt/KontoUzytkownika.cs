﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace Projekt
{
    [Serializable]
    [DataContract]
    public class KontoUzytkownika : Konto, INaPozniej, IDodawanieRecenzji, ICloneable
    {
        DateTime dataUrodzenia;
        List<string> listaUslug;
        List<string> listaNaPozniej;
        static double abonament;

        [DataMember]
        public DateTime DataUrodzenia { get => dataUrodzenia; set => dataUrodzenia = value; }
        [DataMember]
        public List<string> ListaUslug { get => listaUslug; set => listaUslug = value; }
        [DataMember]
        public List<string> ListaNaPozniej { get => listaNaPozniej; set => listaNaPozniej = value; }
        public static double Abonament { get => abonament; set => abonament = value; }

        static KontoUzytkownika()
        {
            abonament = 29.99;
        }

        public KontoUzytkownika() : base()
        {
            DataUrodzenia = DateTime.Now;
            ListaUslug = new List<string>();
            ListaNaPozniej = new List<string>();
        }

        public KontoUzytkownika(string login, string haslo, string imie, string nazwisko,
            DateTime dataUrodzenia, string email) : base(login, haslo, imie, nazwisko, email)
        {
            DataUrodzenia = dataUrodzenia;
            ListaUslug = new List<string>();
            ListaNaPozniej = new List<string>();
        }

        public int Wiek()
        {
            int kontrol = DateTime.Now.Year - DataUrodzenia.Year;
            if (DataUrodzenia.AddYears(kontrol) > DateTime.Now)
            {
                return kontrol - 1;
            }
            else
                return kontrol;
        }

        public void DodajUsluge(string usluga)
        {
            ListaUslug.Add(usluga);
        }

        public void Rezygnuj(string usluga)
        {
            ListaUslug.Remove(usluga.ToString());
        }

        public double ObliczOplate()
        {
            double kosztDodatkowy = 0;
            string[] t;
            string liczba = "";
            Char znak;
            int i = 0;
            double liczbaPomocnicza;

            foreach(string usl in ListaUslug)
            {
                t = usl.Split();
                do
                {
                    znak = t[1][i];
                    liczba += znak;
                    ++i;
                } while (Char.IsDigit(znak) || znak == '.');
                Double.TryParse(liczba, out liczbaPomocnicza);
                kosztDodatkowy += liczbaPomocnicza;
            }
            return Abonament + kosztDodatkowy;
        }

        public override string ToString()
        {
            return $"{Login}{Environment.NewLine}{Imie} {Nazwisko},{Environment.NewLine}Abonamet: {ObliczOplate():C}";
        }

        public void DodajDoObejrzenia(Film f)
        {
            NaPozniej u = new NaPozniej();
            if (listaUslug.Contains(u.ToString()))
            {
                NaPozniej.DodajDoObejrzenia(f, ListaNaPozniej);
            }
            else
            {
                throw new BrakUprawnienException("Błąd. Nie masz uprawnień.");
            }
        }

        public void UsunZListyDoObejrzenia(Film f)
        {
            NaPozniej u = new NaPozniej();
            if (listaUslug.Contains(u.ToString()))
            {
                NaPozniej.Usun(f,ListaNaPozniej);
            }
            else
            {
                throw new BrakUprawnienException("Błąd. Nie masz uprawnień.");
            }
        }

        public void Wybor(Usluga usluga)
        {
            ListaUslug.Add(usluga.ToString());
        }

        public void DodajRecenzje(Recenzja rec, Film f)
        {
            DodawanieRecenzji r = new DodawanieRecenzji();
            if(ListaUslug.Contains(r.ToString()))
            {
                DodawanieRecenzji.DodajRecenzje(rec, f);
            }
            else
            {
                throw new BrakUprawnienException("Błąd. Nie masz uprawnień.");
            }
        }

        public void EdytujRecenzje(Recenzja rec, Film f)
        {

            DodawanieRecenzji r = new DodawanieRecenzji();
            if (ListaUslug.Contains(r.ToString()))
            {
                DodawanieRecenzji.EdytujRecenzje(rec, f);
            }
            else
            {
                throw new BrakUprawnienException("Błąd. Nie masz uprawnień.");
            }
        }

        public void UsunRecenzje(Recenzja rec, Film f)
        {

            DodawanieRecenzji r = new DodawanieRecenzji();
            if (ListaUslug.Contains(r.ToString()))
            {
                DodawanieRecenzji.UsunRecenzje(rec,f);
            }
            else
            {
                throw new BrakUprawnienException("Błąd. Nie masz uprawnień.");
            }
        }


        public object Clone()
        {
            BinaryFormatter bf = new BinaryFormatter();
            BinaryFormatter bffinal = new BinaryFormatter();
            using (MemoryStream ms = new MemoryStream())
            {
                bf.Serialize(ms, this);
                ms.Position = 0;
                return bffinal.Deserialize(ms);
            }
        }
    }


}
