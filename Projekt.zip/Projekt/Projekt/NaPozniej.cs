﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Projekt
{
    [Serializable]
    [DataContract]
    
    public class NaPozniej : Usluga
    {
        public NaPozniej() : base("Na później", 5.5)
        {

        }

        public static void DodajDoObejrzenia(Film film, List<string> lista)
        {
            lista.Add(film.ToString());
            lista.Sort();
        }

        public static void Usun(Film f, List<string> lista)
        {
            lista.Remove(f.ToString());
        }
    }
}